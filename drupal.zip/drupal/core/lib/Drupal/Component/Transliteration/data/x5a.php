<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = array(
  0x00 => 'song', 'wei', 'hong', 'wa', 'lou', 'ya', 'rao', 'jiao', 'luan', 'ping', 'xian', 'shao', 'li', 'cheng', 'xie', 'mang',
  0x10 => 'fu', 'suo', 'mei', 'wei', 'ke', 'chuo', 'chuo', 'ting', 'niang', 'xing', 'nan', 'yu', 'na', 'pou', 'nei', 'juan',
  0x20 => 'shen', 'zhi', 'han', 'di', 'zhuang', 'e', 'pin', 'tui', 'xian', 'mian', 'wu', 'yan', 'wu', 'ai', 'yan', 'yu',
  0x30 => 'si', 'yu', 'wa', 'li', 'xian', 'ju', 'qu', 'zhui', 'qi', 'xian', 'zhuo', 'dong', 'chang', 'lu', 'ai', 'e',
  0x40 => 'e', 'lou', 'mian', 'cong', 'pou', 'ju', 'po', 'cai', 'ling', 'wan', 'biao', 'xiao', 'shu', 'qi', 'hui', 'fan',
  0x50 => 'wo', 'rui', 'tan', 'fei', 'fei', 'jie', 'tian', 'ni', 'quan', 'jing', 'hun', 'jing', 'qian', 'dian', 'xing', 'hu',
  0x60 => 'wan', 'lai', 'bi', 'yin', 'chou', 'nao', 'fu', 'jing', 'lun', 'an', 'lan', 'kun', 'yin', 'ya', 'ju', 'li',
  0x70 => 'dian', 'xian', 'hua', 'hua', 'ying', 'chan', 'shen', 'ting', 'dang', 'yao', 'wu', 'nan', 'chuo', 'jia', 'tou', 'xu',
  0x80 => 'yu', 'wei', 'di', 'rou', 'mei', 'dan', 'ruan', 'qin', 'hui', 'wo', 'qian', 'chun', 'miao', 'fu', 'jie', 'duan',
  0x90 => 'yi', 'zhong', 'mei', 'huang', 'mian', 'an', 'ying', 'xuan', 'jie', 'wei', 'mei', 'yuan', 'zheng', 'qiu', 'shi', 'xie',
  0xA0 => 'tuo', 'lian', 'mao', 'ran', 'si', 'pian', 'wei', 'wa', 'jiu', 'hu', 'ao', 'qie', 'bao', 'xu', 'tou', 'gui',
  0xB0 => 'chu', 'yao', 'pi', 'xi', 'yuan', 'ying', 'rong', 'ru', 'chi', 'liu', 'mei', 'pan', 'ao', 'ma', 'gou', 'kui',
  0xC0 => 'qin', 'jia', 'sao', 'zhen', 'yuan', 'jie', 'rong', 'ming', 'ying', 'ji', 'su', 'niao', 'xian', 'tao', 'pang', 'lang',
  0xD0 => 'nao', 'bao', 'ai', 'pi', 'pin', 'yi', 'piao', 'yu', 'lei', 'xuan', 'man', 'yi', 'zhang', 'kang', 'yong', 'ni',
  0xE0 => 'li', 'di', 'gui', 'yan', 'jin', 'zhuan', 'chang', 'ze', 'han', 'nen', 'lao', 'mo', 'zhe', 'hu', 'hu', 'ao',
  0xF0 => 'nen', 'qiang', 'ma', 'pie', 'gu', 'wu', 'qiao', 'tuo', 'zhan', 'mao', 'xian', 'xian', 'mo', 'liao', 'lian', 'hua',
);
